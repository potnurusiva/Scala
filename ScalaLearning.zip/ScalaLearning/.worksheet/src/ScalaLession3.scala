object ScalaLession3 {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(66); 
  println("Welcome to the Scala worksheet")
  /*
  //Classes
  class Person
  val p = new Person
  println(p)

  class Person1(val name: String, val age: Int)
  val p1 = new Person1("Sumit", 30)
  p1.name
  p1.age

  //Function inside a class is called Method
  class Person2(name: String, age: Int) {
  val x = 20
  def ageDoubler = age * 2
  def salaryDoubler(salary:Int) = salary * 2
  }
  val p2 = new Person2("Sumit", 28)
  p2.x
  p2.ageDoubler
  p2.salaryDoubler(10000)
  
  object Person2 {
  val n_eyes = 2
  def canFly: Boolean = false
  }
  val p3 = new Person2("Sumit", 56)
  Person2.n_eyes
  Person2.canFly
  val mary = Person2
  val john = Person2
  
  println(mary==john)
  
  val p4 = new Person2("Sumit",40)
  println(p3==p4)
  
  
  */
  //Inheritance and Access Modifiers
  class Animal{def eat = println("Eating")
  private def eat1 = println("private")
  protected val eat2 = "Protected"
  }
  class Cat extends Animal {def preferredMeal = println("Milk")
  println(eat2)
  };$skip(972); 
  val c = new Cat;System.out.println("""c  : ScalaLession3.Cat = """ + $show(c ));$skip(8); 
  c.eat;$skip(18); 
  c.preferredMeal

//Abstract Class
  abstract class Animal2 {
  	def sleep = println("sleep")
  	val creatureType : String
  	def eat
  }
	class Dog extends Animal2 {
	val creatureType : String = "canine"
	def eat:Unit = println("Eat")
	};$skip(240); 
  val d = new Dog;System.out.println("""d  : ScalaLession3.Dog = """ + $show(d ));$skip(8); 
  d.eat;$skip(10); 
  d.sleep;$skip(17); val res$0 = 
  d.creatureType
  
  //Traits - similar to abstract class
  trait Carnivore { def preferredMeal}
  trait ColdBlooded { def preferredMeal2 }
  class Crocodile extends Animal2 with Carnivore with ColdBlooded {
  def preferredMeal = println("trait Carnivore")
  def preferredMeal2 = println("trait ColdBlooded")
  val creatureType: String = "Canine"
  def eat = println("Eat flesh")
  };System.out.println("""res0: String = """ + $show(res$0));$skip(395); 
  val croc = new Crocodile;System.out.println("""croc  : ScalaLession3.Crocodile = """ + $show(croc ));$skip(11); 
  croc.eat;$skip(21); 
  croc.preferredMeal;$skip(22); 
  croc.preferredMeal2
  
  //case classes - parameters are automatically promoted to fields no need of val and var
  case class Person3(name:String,age:Int);$skip(188); //Empty class
  val person3 = new Person3("Sumit",30);System.out.println("""person3  : ScalaLession3.Person3 = """ + $show(person3 ));$skip(37); 
  println(person3.name, person3.age);$skip(28); 
  println(person3.toString);$skip(19); 
  println(person3);$skip(40); 
  val person4 = new Person3("Sumit",30);System.out.println("""person4  : ScalaLession3.Person3 = """ + $show(person4 ));$skip(30); 
  println(person3 == person4);$skip(91); 
  
  //companion objects, we need to use 'apply'
  val person5 = Person3.apply("Sumit",50);System.out.println("""person5  : ScalaLession3.Person3 = """ + $show(person5 ));$skip(19); 
  println(person5);$skip(36); 
  val person6 = Person3("Sumit",60);System.out.println("""person6  : ScalaLession3.Person3 = """ + $show(person6 ));$skip(19); 
  println(person6);$skip(31); 
  val person7 = person5.copy();System.out.println("""person7  : ScalaLession3.Person3 = """ + $show(person7 ));$skip(19); 
  println(person7);$skip(37); 
  val person8 = person5.copy(age=45);System.out.println("""person8  : ScalaLession3.Person3 = """ + $show(person8 ));$skip(19); 
  println(person8);$skip(23); 
  println(person8.age)}

}
