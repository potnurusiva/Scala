object ScalaLession2 {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(66); 
  println("Welcome to the Scala worksheet");$skip(2227); 
  /*
  var a = 5
  //impure function - depends on a
  def func(i: Int):Int = {return a + i}
  func(5)
  //impure function - modifying the input value j
  def func1(j:Int):Int = {
  val k = j + 1
  return k
  }
  func1(10)
  //Pure function
  def func2(i:Int,a:Int):Int = {return a+i}
  func2(20,5)
  def func3(a:Int):Int = {return a+1}
  func3(9)
  
  //Impure function as there is side effect - prints "Hello"
  def func4(a:Int): Any = {println("Hello");return a}
  func4(30)
  
  def func5(a:Int): Int = {return a}
  func5(100)
  
 
  //First class functions
  //Assign a function to a variable
  def doubler(i:Int) = { i*2 }
  val b = doubler(_)
  b(2)
  b(10)
  //Pass a function as parameter to another function
  def func(a:Int) = {a*3}
  def func2(i:Int, f:Int=>Int) ={f(i)}
  func2(5,func)
  func2(10,func)
  //Return a function from a function
  def func3(x:Int) = {func(x)}
  func3(10)
  
  
  //Higher order functions
  //Map
  val a = 1 to 10        //Range
  def doubler(x:Int):Int = {x*2}
  a.map(doubler)
  //Anonymous function
  val b = 1 to 10
  b.map(x=>x*x)
  
    
  //Loop vs Recursion vs Tail recursion
  //Loop
  def fact(x:Int) :Int = {
  var result:Int = 1
  for(i<- 1 to x) result = result * i
  return result
  }
  fact(5)
  
  
  //Recursion
  def fact1(x:Int):Int = {
  if(x == 1) 1
  else x * fact1(x - 1)
  }
  fact1(4)
  
  //Tail recursion
  def fact2(y:Int,result:Int):Int = {
  if(y==1)result
  else fact2(y-1,result*y)
  }
  fact2(6,1)
  
  
  
  
  //Closure
  def areaOfCircle = {val pi = 3.14; x:Int => pi*x*x}
  //val pi =3.5
  areaOfCircle(10)
  val a = areaOfCircle
  a(10)
  val pi = 4
  a(10)
  
  
  //Operators - Menthods and Functions
  val a = 5
  val b = 6
  a.compare(b)
  a-b
  a.+(b)
  a.*(b)
  a.sum(b)
  
  
  //Place holder syntax
  
  val c = 1 to 10
  c.map(_*2)
  c.reduce((x:Int, y:Int) =>x+y)
  c.reduce(_+_)
  c.reduce(_*_)
  
  c.reduce((x:Int,y:Int)=>x+y-x-y)
  
  
  //Partially applied functions
  
  def divideFunc(x:Double, y:Double):Double = {x/y}
  divideFunc(5,10)
  
  val inverse = divideFunc(1,_:Double)
  inverse(10)
  
  val increment = {x:Int=> x+1}
  increment(10)
  
  */
  //Generic functions
  def genericSum(x:Int, y:Int, f:Int=>Int)={f(x)+f(y)};System.out.println("""genericSum: (x: Int, y: Int, f: Int => Int)Int""");$skip(23); val res$0 = 
  genericSum(2,3,x=>x);System.out.println("""res0: Int = """ + $show(res$0));$skip(25); val res$1 = 
  genericSum(2,3,x=>x*x);System.out.println("""res1: Int = """ + $show(res$1));$skip(27); val res$2 = 
  genericSum(2,3,x=>x*x*x);System.out.println("""res2: Int = """ + $show(res$2));$skip(86); 
  //Creating a brand new function
  val sumOfSquares = genericSum(_:Int,_:Int,x=>x*x);System.out.println("""sumOfSquares  : (Int, Int) => Int = """ + $show(sumOfSquares ));$skip(20); val res$3 = 
  sumOfSquares(2,3);System.out.println("""res3: Int = """ + $show(res$3));$skip(152); 
  
  
  //Function currying
  //Adding syntax sugar but similar to Partially Applied Functions
  def genericSum2(x:Int,y:Int)(f:Int=>Int) = {f(x)+f(y)};System.out.println("""genericSum2: (x: Int, y: Int)(f: Int => Int)Int""");$skip(27); val res$4 = 
  genericSum2(5,3)(x=>x*x);System.out.println("""res4: Int = """ + $show(res$4));$skip(61); 
  
  
  val sumOfSquares2 = genericSum2(_:Int,_:Int)(x=>x*x);System.out.println("""sumOfSquares2  : (Int, Int) => Int = """ + $show(sumOfSquares2 ));$skip(23); val res$5 = 
  sumOfSquares2(10,20);System.out.println("""res5: Int = """ + $show(res$5))}
  
}
