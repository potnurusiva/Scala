object ScalaLession1 {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(219); 

//Scala worksheets are compatible with 2.12 version so change scala compiler settings from Project-->Properties
// def main(args: Array[String]) = {
  
  println("Welcome to the Scala worksheet");$skip(17); 
  println("Hai");$skip(22); 
  val a:String = "hi";System.out.println("""a  : String = """ + $show(a ));$skip(13); 
  println(a);$skip(6); val res$0 = 
  1+2;System.out.println("""res0: Int(3) = """ + $show(res$0));$skip(29); 
  
  var b: String = "hello";System.out.println("""b  : String = """ + $show(b ));$skip(14); 
  b = "there";$skip(13); 
  println(b);$skip(24); 
  val c: Boolean = true;System.out.println("""c  : Boolean = """ + $show(c ));$skip(23); 
  
  val d: Char = 'a';System.out.println("""d  : Char = """ + $show(d ));$skip(41); 
  val e: Double = 3.12345678901234567890;System.out.println("""e  : Double = """ + $show(e ));$skip(41); 
  val f: Float = 3.12345678901234567890f;System.out.println("""f  : Float = """ + $show(f ));$skip(33); 
  val g: Long = 123456789012345l;System.out.println("""g  : Long = """ + $show(g ));$skip(20); 
  val h: Byte = 127;System.out.println("""h  : Byte = """ + $show(h ));$skip(105); 
  println("Combined result: " + a + " " + b + " " + c + " " + d + " " + e + " " + f + " " + g + " " + h);$skip(28); 
  val name: String = "siva";System.out.println("""name  : String = """ + $show(name ));$skip(36); 
  println("hello name how are you");$skip(37); 
  println("hello $name how are you");$skip(63); 
  //String interpolation
  println(s"hello $name how are you");$skip(59); 
  //Float interpolation
  println(f"value of f is $f%.3f");$skip(59); 
  //raw interpolation
  println(raw"hello \n how are you");$skip(16); 
  val abc = 1>2;System.out.println("""abc  : Boolean = """ + $show(abc ));$skip(24); 
  val x: String = "abc";System.out.println("""x  : String = """ + $show(x ));$skip(24); 
  val y: String = "abc";System.out.println("""y  : String = """ + $show(y ));$skip(17); 
  val z = x == y;System.out.println("""z  : Boolean = """ + $show(z ));$skip(58); 
  //if condition
  if(6 > 3) println(x)
  else println(z);$skip(55); 
  //match case - similar to Switch case
  var num = 10;System.out.println("""num  : Int = """ + $show(num ));$skip(139); 
  num match {
  case 1 => println("One")
  case 2 => println("Two")
  case 3 => println("Three")
  case _ => println("Something else")
  };$skip(82); 
  //Loops
  //for loop
  for(x <- 1 to 5) {val squared = x * x; println(squared)};$skip(72); 
  
  //while loop
  while(num >= 5){
  println(num)
  num = num - 1
  };$skip(76); 
  //do while loop
  do{
  println(num)
  num = num - 1
  } while (num >= 1);$skip(37); val res$1 = 
  
  
  //block
  {val x = 10; x+20};System.out.println("""res1: Int = """ + $show(res$1));$skip(30); val res$2 = 
  {val y = 10
  y+20
  10
  };System.out.println("""res2: Int = """ + $show(res$2));$skip(54); 
  
  //functions
  def squareIt(x: Int) : Int = {x*x};System.out.println("""squareIt: (x: Int)Int""");$skip(14); val res$3 = 
  squareIt(2);System.out.println("""res3: Int = """ + $show(res$3));$skip(33); 
  def cubeIt(x: Int) = x * x * x;System.out.println("""cubeIt: (x: Int)Int""");$skip(12); val res$4 = 
  cubeIt(4);System.out.println("""res4: Int = """ + $show(res$4));$skip(58); 
  def transformIt(x:Int, f:Int=> Int) :Int = {
  f(x)
  };System.out.println("""transformIt: (x: Int, f: Int => Int)Int""");$skip(26); val res$5 = 
  transformIt(5,squareIt);System.out.println("""res5: Int = """ + $show(res$5));$skip(24); val res$6 = 
  transformIt(9,cubeIt);System.out.println("""res6: Int = """ + $show(res$6));$skip(28); val res$7 = 
  transformIt(2, x=> x *10);System.out.println("""res7: Int = """ + $show(res$7));$skip(39); val res$8 = 
  transformIt(2, x=>{val y =x*2; y*y});System.out.println("""res8: Int = """ + $show(res$8));$skip(60); 
  
  
  //Collections
  //Array
  val a1 = Array(1,2,3,4,5);System.out.println("""a1  : Array[Int] = """ + $show(a1 ));$skip(14); 
  println(a1);$skip(28); 
  println(a1.mkString("|"));$skip(26); 
  for(i <- a1) println(i);$skip(12); 
  a1(2) = 7;$skip(17); 
  println(a1(2));$skip(36); 
  //List
  val b1 = List(1,2,3,4,5);System.out.println("""b1  : List[Int] = """ + $show(b1 ));$skip(17); 
  println(b1(2));$skip(19); 
  println(b1.head);$skip(19); 
  println(b1.tail);$skip(25); 
  for(i<- b1) println(i);$skip(9); val res$9 = 
  b1.sum;System.out.println("""res9: Int = """ + $show(res$9));$skip(13); val res$10 = 
  b1.reverse;System.out.println("""res10: List[Int] = """ + $show(res$10));$skip(9); val res$11 = 
  b1.min;System.out.println("""res11: Int = """ + $show(res$11));$skip(9); val res$12 = 
  b1.max;System.out.println("""res12: Int = """ + $show(res$12));$skip(9); val res$13 = 
  20::b1;System.out.println("""res13: List[Int] = """ + $show(res$13));$skip(8); val res$14 = 
  b1(0);System.out.println("""res14: Int = """ + $show(res$14));$skip(46); 
  //Tuple
  val x1 = ("Siva",10000,true,3.14);System.out.println("""x1  : (String, Int, Boolean, Double) = """ + $show(x1 ));$skip(8); val res$15 = 
  x1._1;System.out.println("""res15: String = """ + $show(res$15));$skip(8); val res$16 = 
  x1._2;System.out.println("""res16: Int = """ + $show(res$16));$skip(25); 
  val y1 = (107,"Sumit");System.out.println("""y1  : (Int, String) = """ + $show(y1 ));$skip(26); 
  val z1 = 107 -> "Sumit";System.out.println("""z1  : (Int, String) = """ + $show(z1 ));$skip(19); 
  val z2 = y1 ==z1;System.out.println("""z2  : Boolean = """ + $show(z2 ));$skip(32); 
  
  //Range
  val rng = 1 to 5;System.out.println("""rng  : scala.collection.immutable.Range.Inclusive = """ + $show(rng ));$skip(28); 
  for (j <- rng) println(j);$skip(26); 
  
  val rng1 = 1 until 5;System.out.println("""rng1  : scala.collection.immutable.Range = """ + $show(rng1 ));$skip(29); 
  for (k <- rng1) println(k);$skip(68); 
  
  
  //Set
  val set1 = Set(1,1,1,1,2,3,3,2,2,3,3,4,5,6,7,9,8,9);System.out.println("""set1  : scala.collection.immutable.Set[Int] = """ + $show(set1 ));$skip(16); 
  println(set1);$skip(11); val res$17 = 
  set1.min;System.out.println("""res17: Int = """ + $show(res$17));$skip(11); val res$18 = 
  set1.max;System.out.println("""res18: Int = """ + $show(res$18));$skip(11); val res$19 = 
  set1.sum;System.out.println("""res19: Int = """ + $show(res$19));$skip(12); val res$20 = 
  set1.head;System.out.println("""res20: Int = """ + $show(res$20));$skip(12); val res$21 = 
  set1.tail;System.out.println("""res21: scala.collection.immutable.Set[Int] = """ + $show(res$21));$skip(66); 
  
  
  
  //Map
  val map1 = Map(1->"Siva",2->"Great",1->"Nice");System.out.println("""map1  : scala.collection.immutable.Map[Int,String] = """ + $show(map1 ));$skip(52); 
  val map2 = Map((1,"Siva"),(2,"Great"),(1,"Nice"));System.out.println("""map2  : scala.collection.immutable.Map[Int,String] = """ + $show(map2 ));$skip(28); 
  val result1 = map1.get(1);System.out.println("""result1  : Option[String] = """ + $show(result1 ));$skip(28); 
  val result2 = map2.get(1);System.out.println("""result2  : Option[String] = """ + $show(result2 ));$skip(28); 
  val result3 = map1.get(2);System.out.println("""result3  : Option[String] = """ + $show(result3 ));$skip(28); 
  val result4 = map2.get(2);System.out.println("""result4  : Option[String] = """ + $show(result4 ))}
  
  
  
  
// }
  
}
