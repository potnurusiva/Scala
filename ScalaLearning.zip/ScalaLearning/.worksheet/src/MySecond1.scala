object MySecond1 {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(306); 
//Scala worksheets are compatible with 2.12 version so change scala compiler settings from Project-->Properties
                                              
  //
  //Diff between strict val and lazy val
  //def main(args : Array[String]) = {
  println("Welcome to the Scala worksheet");$skip(13); 
  val r = 10;System.out.println("""r  : Int = """ + $show(r ));$skip(63); 
  val a = {
  println("Area of cirlce")
  3.14 * r * r
  				};System.out.println("""a  : Double = """ + $show(a ));$skip(13); 
  println(a);$skip(73); 
  
  lazy val b = {
  println("Circle Area")
  3.14 * r * r
           };System.out.println("""b: => Double = <lazy>""");$skip(13); 
  println(b);$skip(79); 
  //}


  //Monad concept - not a class or a trait
  val list1 = List(1,2,3,4);System.out.println("""list1  : List[Int] = """ + $show(list1 ));$skip(28); 
  val list2 = List(5,6,7,8);System.out.println("""list2  : List[Int] = """ + $show(list2 ));$skip(57); 
  val list3 = list1.flatMap{x => list2.map{ y => x + y}};System.out.println("""list3  : List[Int] = """ + $show(list3 ))}
  
  
  
}
