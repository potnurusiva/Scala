import scala.math
import scala.io.StdIn._
object ScalaQuiz {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(104); 
  println("Welcome to the Scala worksheet");$skip(1071); 
 /*
 val student = ("Student1", 90, "Bangalore", "Postgraduate")
 println(student)
 val x = List.range(1, 10)
 val doubleList = x.map( _* 2)
 val doubleList2 = x.map((i : Int) => i * i; i * 2)
 */
 //Problem 1
    def main(args: Array[String]) = {
        //val input1: Int = scala.io.StdIn.readLine()
        val input1: Int = readInt()        // Reading input from STDIN
        //println("Hi, " + input1 + ".")                // Writing output to STDOUT
        val input2: String = readLine()        // Reading input from STDIN
        //println("Hi, " + input2 + ".")                // Writing output to STDOUT
        val input: Array[Int] = input2.split(" ").map(x=>x.toInt)
        var result = 0
        //println("i1 :" + i1)
        //println("result" + result)
        for(i <- input) {
            println(i)
            //val sqrt1 = Math.sqrt(i)
            //if(sqrt1.ceil - sqrt1 == 0) result = result + 1
            
            if(scala.math.sqrt(i) % 1 == 0){
                result = result + 1
            }
        }
        println(result)
    };System.out.println("""main: (args: Array[String])Unit""")}
    
    
  
  /*
  //Problem 3
  val input1 = "hello how are you"
  input1.reverse
  var output: String = ""
  val input2 = input1.split(" ")
  for(i<-input2) {output= output + " " + i.reverse}
  println(output)
  var output2:Array[String] = input2
  for(i<-0 to input2.length - 1) {
  output2(i)=input2(input2.length - 1 -i)}
  println(output2.mkString(" "))
  
  */
}
 
 
 