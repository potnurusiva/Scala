package snippet

object sample {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(76); 
  println("Welcome to the Scala worksheet");$skip(12); 
  val a = 2;System.out.println("""a  : Int = """ + $show(a ));$skip(12); 
  val b = 3;System.out.println("""b  : Int = """ + $show(b ));$skip(14); 
  val c = a+b;System.out.println("""c  : Int = """ + $show(c ));$skip(13); 
  println(c)}
}
