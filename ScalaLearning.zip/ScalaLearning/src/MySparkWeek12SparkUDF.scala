import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object MySparkWeek12SparkUDF extends App {
  
  println("Entering into Spark")
  //Step 2 - Setting the logging level to Error
  Logger.getLogger("org").setLevel(Level.ERROR)
  
  //creating sparkConf object
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name","MySparkWeek12SparkUDF")
  sparkConf.set("spark.master","local[2]")
  
  //Step1 -creating a spark session
  val spark = SparkSession.builder()
              .config(sparkConf)
              .getOrCreate()
      
  val df = spark.read
                .format("csv")
                .option("header",false)
                .option("inferSchema",true)
                .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\12Week_ApacheSparkStructuredAPIPart2\\dataset1.txt")
                .load()
                
  //Adding headers (column names)
  val df1 = df.toDF("Name","Age","City")
  //converting the above DF to DS using case class
  import spark.implicits._
  case class Person(name :String, age: Int, city: String)
  val ds = df1.as[Person]
  println("Dataset")
  ds.show
  //Dataset to Dataframe conversion
  val df2 = ds.toDF()
  println("DataFrame")

  df2.show
  
  //Function creation
  def ageCheck(age:Int) = {
    if (age > 18) "Y" else "N"
  }
  
  val parseAgeFunction = udf(ageCheck(_:Int):String)
  val df3 = df1.withColumn("Adult",parseAgeFunction(column("age")))
  println("Output with column object expression UDF")
  df3.show
  
  
  //Sql/String expression UDF
  spark.udf.register("parseAgeFucntion2",ageCheck(_:Int):String)
  val df4 = df1.withColumn("Voter",expr("parseAgeFucntion2(age)"))
  println("Output with sql/string expression UDF")
  df4.show
  
  //Other way using Anonymous functions
  spark.udf.register("parseAgeFunction3",(x:Int) => { if (x>18) "Y" else "N"})
  val df5 = df1.withColumn("Citizen",expr("parseAgeFunction3(age)"))
  println("Output with sql/string expression UDF using Anonymous function")
  df5.show
  
  //Spark catalog registered functions
  //spark.catalog.listFunctions().show()
  spark.catalog.listFunctions().filter( x => x.name == "parseAgeFunction").show()
      
      
      
  spark.stop()


}




