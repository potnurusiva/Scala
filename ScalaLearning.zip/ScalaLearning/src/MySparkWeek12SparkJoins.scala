import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DateType
import org.apache.spark.sql.expressions.Window

object MySparkWeek12SparkJoins extends App {
  
  println("Entering into Spark")
  //Step 2 - Setting the logging level to Error
  Logger.getLogger("org").setLevel(Level.ERROR)
  
  //creating sparkConf object
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name","MySparkWeek12SparkUDF2")
  sparkConf.set("spark.master","local[2]")
  
  //Step1 -creating a spark session
  val spark = SparkSession.builder()
              .config(sparkConf)
              .getOrCreate()
      
  val ordersDf = spark.read
                .format("csv")
                .option("header",true)
                .option("inferSchema",true)
                .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\12Week_ApacheSparkStructuredAPIPart2\\orders.csv")
                .option("mode","DROPMALFORMED")
                .load()
  println("ordersDf")
  //ordersDf.show
  
  val customersDf = spark.read
                .format("csv")
                .option("header",true)
                .option("inferSchema",true)
                .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\12Week_ApacheSparkStructuredAPIPart2\\customers.csv")
                .load()
  println("customersDf")
  //customersDf.show
  
  //Broadcast join is set to false - verify it in DAG-SQL
  spark.sql("SET spark.sql.autoBroadcastJoinThreshold = -1")
  
  val joinedDf = ordersDf.join(customersDf,ordersDf.col("order_customer_id") === customersDf.col("customer_id"),"inner")
  println("Joined DF")
  joinedDf.show
  
  val joinCondition = ordersDf.col("order_customer_id") === customersDf.col("customer_id")
  val joinTypeInner = "inner"
  //To manually perform the broadcast join - you know that customersdf is small enough
  val joinedDf1 = ordersDf.join(broadcast(customersDf),joinCondition,joinTypeInner).sort("order_customer_id")
  println("Joined DF1 inner")
  joinedDf1.show()
  
  val joinTypeOuter = "outer"
  val joinedDf2 = ordersDf.join(customersDf,joinCondition,joinTypeOuter).sort("order_customer_id")
  println("Joined DF2 outer")
  joinedDf2.show()
  
  val joinTypeRight = "right"
  val joinedDf3 = ordersDf.join(customersDf,joinCondition,joinTypeRight).sort("order_customer_id")
  println("Joined DF3 Right outer")
  joinedDf3.show()
  
  val joinTypeLeft = "left"
  //null values replaced with -1
  val joinedDf4 = ordersDf.join(customersDf,joinCondition,joinTypeLeft)
                          .sort("order_customer_id")
                          .withColumn("order_customer_id",expr("coalesce(order_customer_id,-1)"))
  println("Joined DF4 Left outer")
  joinedDf4.show(100)
  
  scala.io.StdIn.readLine()  
  spark.stop()
  
}




