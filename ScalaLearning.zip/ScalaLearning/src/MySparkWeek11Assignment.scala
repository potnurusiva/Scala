import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.FloatType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.SaveMode




object MySparkWeek11Assignment extends App{
  
  
  println("Entering into Spark")
  //Step 2 - Setting the logging level to Error
  Logger.getLogger("org").setLevel(Level.ERROR)
  
  //creating sparkConf object
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name","MySparkWeek11Assignment")
  sparkConf.set("spark.master","local[2]")
  
  //Step1 -creating a spark session
  val spark = SparkSession.builder()
              .config(sparkConf)
              .getOrCreate()
  
  // Step 3 Explicit schema definition programmatically using StructType
  val windowDataSchema = StructType(List(
      StructField("Country",StringType,false),
      StructField("Weeknum",IntegerType,true),
      StructField("NumInvoices",IntegerType,true),
      StructField("TotalQuantity",IntegerType,true),
      StructField("Amount",FloatType,true)
      )
      )
      
  // Step 3 contd.. Loading the file and creation of dataframe using dataframe reader API, using explicitly
  //specified schema
    
  val windowDf = spark.read
                 .format("csv")
                 .option("header",false)
                // .option("inferSchema",true)
                 .schema(windowDataSchema)
                 .option("mode","DROPMALFORMED")
                 .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/windowdata.csv")
                 .load
  windowDf.show
  windowDf.printSchema
  
  //Step 4: Saving the data in Parquet format using Dataframe Writer API
 //Data is two-level partitioned on Country and weeknum column , these columns have low cardinality
 //Default output format is parquet
  
  
  windowDf.write.partitionBy("Country","weekNum")
               //.format("parquet") --Default format
                .mode(SaveMode.Overwrite)
                .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/windowdataOutput")
                .save()
   
  //val sparkVersion = "2.4.0" "org.apache.spark" %% "spark-avro" % sparkVersion              
  windowDf.write.format("avro") 
                .partitionBy("Country")
                .mode(SaveMode.Overwrite)
                .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/windowdataOutputAvro")
                .save()
}




