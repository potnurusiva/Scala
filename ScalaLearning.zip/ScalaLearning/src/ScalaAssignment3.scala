import scala.math
import scala.io.StdIn._

object ScalaAssignment3 {
  def main(args: Array[String]) = {
        //val input1: Int = scala.io.StdIn.readLine()
        println("Enter your first input line\n")
        val input1: String = readLine()        
        val output1: String = input1.reverse
        println("First output :" + output1)
        val output2 = input1.split(" ").map(x=>x.reverse)
        println("Second output:" + output2.mkString(" "))
        val output3 = input1.split(" ").reverse
        println("Third output :" + output3.mkString(" "))
    }                  
}