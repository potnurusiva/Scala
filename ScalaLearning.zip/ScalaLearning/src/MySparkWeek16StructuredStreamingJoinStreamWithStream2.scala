import org.apache.spark.SparkContext
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Seconds
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.types.LongType



object MySparkWeek16StructuredStreamingJoinStreamWithStream2 extends App{
  
  Logger.getLogger("org").setLevel(Level.ERROR)
  //create spark session
  println("Welcome to Structured Streaming")
  val spark = SparkSession.builder()
              .master("local[2]")
              .appName("MySparkWeek16StructuredStreamingJoinStreamWithStream2")
              .config("spark.sql.shuffle.partitions",2)
              .config("spark.streaming.stopGracefullyOnShutdown","true")
           //   .config("spark.sql.streaming.schemaInference","true")
              .getOrCreate()
  
   
  val impressionsSchema = StructType(List(StructField("impressionId", IntegerType),
                                     StructField("impressionTime", TimestampType),
                                     StructField("CampaignName", StringType))) 
  
  val impressionsDf = spark.readStream
                      .format("json")
  .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\16Week_ApacheSparkStreamingPart-2\\ImpressionsInputStream")
                     // .option("inferSchema",true)
                      .option("maxFilesPerTrigger",1)
                     .schema(impressionsSchema)
                     .load()
                     
  //when we use socket as datasource
  //val valueDf = impressionsDf.select(from_json(col("value"),impressionsSchema).alias("value"))                    
  
  impressionsDf.printSchema() 
  
  val impressionsDfNew =  impressionsDf.withWatermark("impressionTime","30 minutes")                  
                     
                     
  val clicksSchema = StructType(List(StructField("clickId", IntegerType),
                                     StructField("clickTime", TimestampType))) 
  
  val clicksDf = spark.readStream
                      .format("json")
  .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\16Week_ApacheSparkStreamingPart-2\\ClicksInputStream")
                     // .option("inferSchema",true)
                      .option("maxFilesPerTrigger",1)
                     .schema(clicksSchema)
                     .load()
                     
   clicksDf.printSchema()                   
   val clicksDfNew =  clicksDf.withWatermark("clickTime","30 minutes")                   
  
  //joining stream with static                    
  val joinCondition = expr("impressionId == clickId AND clickTime BETWEEN impressionTime AND impressionTime + interval 15 minute")
  val joinType      = "leftOuter" //"leftouter", "rightouter" , "inner"
  
  val enrichedDf = impressionsDfNew.join(clicksDfNew,joinCondition,joinType)
                                  // .drop(clicksDfNew.col("clickId"))
  
  //write output to the sink 
  val resultQuery = enrichedDf.writeStream
                     .format("console")
                     .outputMode("append") //update, append
                     .option("checkpointLocation","checkpointLocation_1")
                   //.option("cleanSource","delete")
                     .option("cleanSource","archive")
                     .option("sourceArchiveDir","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\16Week_ApacheSparkStreamingPart-2\\OrdersArchiveStream") 
                     .trigger(Trigger.ProcessingTime("10 Second"))
                     .start()
  resultQuery.awaitTermination()
                     
  
}