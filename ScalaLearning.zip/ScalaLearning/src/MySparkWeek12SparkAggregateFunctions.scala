import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DateType
import org.apache.spark.sql.expressions.Window

object MySparkWeek12SparkAggregateFunctions extends App {
  
  println("Entering into Spark")
  //Step 2 - Setting the logging level to Error
  Logger.getLogger("org").setLevel(Level.ERROR)
  
  //creating sparkConf object
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name","MySparkWeek12SparkUDF2")
  sparkConf.set("spark.master","local[2]")
  
  //Step1 -creating a spark session
  val spark = SparkSession.builder()
              .config(sparkConf)
              .getOrCreate()
      
  val df = spark.read
                .format("csv")
                .option("header",true)
                .option("InferSchema",true)
                .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\12Week_ApacheSparkStructuredAPIPart2\\order_data.csv")
                .load()
  df.createOrReplaceTempView("Sales")              
                
  println("1. Simple agregate transformations")
  println("Column object expression")
  df.select(count("*") as "total_row_count", 
      sum("quantity") as "total_quantity",
      avg("unitPrice") as "AvgUnitPrice",
      countDistinct("InvoiceNo") as "CountDistinct"
      ).show()
   
  println("Sql /String expression")
  df.selectExpr("count(stockCode) as total_row_count",
                "sum(quantity) as total_quantity",
                "avg(unitPrice) as avgUnitPrice",
                "count(Distinct(InvoiceNo)) as countDistinct"
                ).show()
  

  println("Spark SQL")
  df.createOrReplaceTempView("Sales")
  spark.sql("""select count(*) as total_row_count,sum(Quantity) as total_quantity,
               avg(UnitPrice) as AvgUnitPrice,count(distinct(InvoiceNo)) as countDistinct 
               from Sales""").show()
  
  println("2. Group By Aggregate transformations")
  println("Column object expression")
  val summaryDf = df.groupBy("country", "InvoiceNo")
                    .agg(sum("quantity").as("TotalQuantity"),
                         sum(expr("quantity * unitprice")).as("InvoiceValue")
                    )
  summaryDf.show
  println("String/sql expression")
  val summaryDf2 = df.groupBy("country","InvoiceNo")
                     .agg(expr("sum(quantity) as total_quantity"),
                          expr("sum(quantity * unitprice) as invoicevalue")
                         )
  summaryDf2.show
  println("Spark sql expression")
  val summaryDf3 = spark.sql("""select country,InvoiceNo, 
               sum(quantity) as totalQuantity,
               sum(quantity * Unitprice) as invoiceValue 
               from Sales
               group by country, invoiceNo""")
  summaryDf3.show          

  
  //Window aggregations
  println("Windowing aggregations")
  
  val windowDf = spark.read
                      .format("csv")
                      .option("header",true)
                      .option("inferSchema",true)
                      .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\12Week_ApacheSparkStructuredAPIPart2\\windowdata.csv")
                      .load()
  val windowDf1 = windowDf.toDF("country","weekNum","numInvoices","totalQuantity","invoiceValue")
  val myWindow = Window.partitionBy("country")
                       .orderBy("weeknum")
                       .rowsBetween(Window.unboundedPreceding,Window.currentRow)
  val myDf = windowDf1.withColumn("RunningTotal",sum("invoicevalue").over(myWindow))
  myDf.show
  spark.stop()
}




