import org.apache.spark.SparkContext
import org.apache.log4j.Level
import org.apache.log4j.Logger

object MySparkWeek10KeyWordAmount extends App{
  
  //calculating the total cost incured for searching a word
  println("Entering here")
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","MySparkWeek10KeyWordAmount")
  //input
  //search terms,matching,.......,avg.cost, cost ==>big data contents,match,....,24.09
  val initialRdd = sc.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/10Week_ApacheSpark_inDepth/bigdatacampaigndata.csv")
  //output
  //cost, search terms ==> 24.09, big data contents
  val mappedInput = initialRdd.map(x => (x.split(",")(10).toFloat,x.split(",")(0)))
  //input 24.09,big data contents
  //output 24.09 big
  //       24.09 data
  //       24.09 contents
  val words = mappedInput.flatMapValues(x => x.split(" "))
  //swap the key value pair
  val finalMapped = words.map(x => (x._2.toLowerCase,x._1))
  //total the value of cost
  val total = finalMapped.reduceByKey((x,y) => (x+y))
  val sorted = total.sortBy(x => x._2, false) //sort the data in descending order
  sorted.take(20).foreach(println)
  
}
