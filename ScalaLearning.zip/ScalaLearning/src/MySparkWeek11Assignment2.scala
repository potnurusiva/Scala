import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.FloatType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.SaveMode




object MySparkWeek11Assignment2 extends App{
  
  
  println("Entering into Spark")
  //Step 2 - Setting the logging level to Error
  Logger.getLogger("org").setLevel(Level.ERROR)
  
  //creating sparkConf object
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name","MySparkWeek11Assignment")
  sparkConf.set("spark.master","local[2]")
  
  //Step1 -creating a spark session
  val spark = SparkSession.builder()
              .config(sparkConf)
              .getOrCreate()
  
  val rddFromFile = spark.sparkContext.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/windowdata.csv")
  case class windowDataSchema(Country: String,Weeknum:Int,NumInvoices:Int,TotalQuantity:Int,Amount:Float)
  
  import spark.implicits._
  //val windowDf = spark.createDataFrame(rddFromFile) --> this will only work with List, Array
  val windowDf = rddFromFile.map(parser).toDF().toDF("Country","Weeknum","NumInvoices","TotalQuantity","Amount")
  def parser(line:String):windowDataSchema = {
    val fields = line.split(",")
    val country = fields(0)
    val weeknum = fields(1).toInt
    val numInvoices = fields(2).toInt
    val totalQuantity = fields(3).toInt
    val amount = fields(4).toFloat
    windowDataSchema(country,weeknum,numInvoices,totalQuantity,amount)
  }
  //val windowDs = windowDf.as[windowDataSchema]
  
  windowDf.show
  windowDf.printSchema
  
  //windowDs.show
  //windowDs.printSchema
  
  //Save as Json file            
  windowDf.write.format("json") 
                .partitionBy("Country")
                .mode(SaveMode.Overwrite)
                .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/windowdataOutputJson")
                .save()
  //into 8 files
  windowDf.repartition(8).write.format("json")
              //  .bucketBy(8,"Country")
                .mode(SaveMode.Overwrite)
                .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/windowdataOutputJsonBuckets")
                .save()                
                
}




