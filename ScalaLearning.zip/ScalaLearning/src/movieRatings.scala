import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkContext


//object wordCount {
//  def main(args: Array[String]) = {}
//}
object movieRatings extends App {
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","wordCount")
  val input = sc.textFile("c:/users/posiva/Desktop/Work/Exxon/BigData/9Week-ApacheSpark _GeneralPurposeClusterComputingFramework/moviedata.data")
  //input - user ID, movie ID, ratings given, timestamp -> output ratings given 
  //0  1234  3  848484848  -> 3
  val mappedInput = input.map(x=>x.split("\t")(2).toInt) //getting only ratings
  
  //input 3 --> output (3,1)
  val transformedInput = mappedInput.map(x => (x,1))
  //input (3,1) (3,1) -> output (3,2)
  val ratingsCount = transformedInput.reduceByKey((x,y) => (x+y)) //pair RDD
  val sortedTotal = ratingsCount.sortBy(x=> x._1,false) //sort by value - amount spent, descending order
  val result = sortedTotal.collect
  println("Output:")
  result.foreach(println)
  /*
  val result = mappedInput.countByValue
  println("Output:")
  * 
  */
  result.foreach(println)
  //scala.io.StdIn.readLine()   //this statement is to visualize the DAG
  
}