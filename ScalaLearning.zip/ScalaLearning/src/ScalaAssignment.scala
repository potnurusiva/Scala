import scala.math
import scala.io.StdIn._

object ScalaAssignment {
  def main(args: Array[String]) = {
        //val input1: Int = scala.io.StdIn.readLine()
        println("Enter your first input\n")
        val input1: Int = readInt()        // Reading input from STDIN
        //println("Hi, " + input1 + ".")                // Writing output to STDOUT
        println("Enter your second input of all integers with spaces\n")
        val input2: String = readLine()        // Reading input from STDIN
        //println("Hi, " + input2 + ".")                // Writing output to STDOUT
        val input: Array[Int] = input2.split(" ").map(x=>x.toInt)
        var result = 0
        //println("i1 :" + i1)
        //println("result" + result)
        for(i <- input) {
            //println(i)
            //val sqrt1 = Math.sqrt(i)
            //if(sqrt1.ceil - sqrt1 == 0) result = result + 1
                        if(scala.math.sqrt(i) % 1 == 0){
                                    result = result + 1
                                }
        }
        println("Number of perfect sqaures are :" + result)
    }                  
}