import org.apache.spark.SparkContext
import org.apache.log4j.Level
import org.apache.log4j.Logger
import scala.io.Source
import breeze.linalg.sum

object MySparkWeek10LogLevel extends App{
  
  //calculating the total cost incurred for searching a word
  println("Entering here")
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","MySparkWeek10LogLevel")
  val myList = List("warn: Tuesday 4 September 0405",
      "error: Tuesday 4 September 0405",
      "error: Tuesday 4 September 0405")
  //Created a list not from a file, it's in local, so we need to distribute this data
  val originalRdd = sc.parallelize(myList)
  val newPairRdd  = originalRdd.map ( x =>
    {
      val columns = x.split(":")
      val logLevel = columns(0)
      (logLevel,1)
    }
    )
  //other way  
  //val newPairRdd  = originalRdd.map(x => (x.split(":")(0),x.split(":")(1)))
  
    val resultRdd = newPairRdd.reduceByKey((x,y) => (x+y)).sortBy(x => x._2)
    println("Reduce By Key")
    resultRdd.collect().foreach(println)
    
    println("Group By Key")
    //Group By Key
    //val resultGroupByRdd = newPairRdd.groupByKey.collect().foreach(x => println(x._1,x._2.size))
    val resultGroupByRdd = newPairRdd.groupByKey.collect.foreach(x => println(x._1,x._2.size))

    
    //
    println("Paralleism, Num of partitons")
    println("defaultParallelism :" + sc.defaultParallelism)
    println("defaultMinPartitions :" +sc.defaultMinPartitions)
    println("getNumPartitions :" + resultRdd.getNumPartitions)
    scala.io.StdIn.readLine()
    
  
}
