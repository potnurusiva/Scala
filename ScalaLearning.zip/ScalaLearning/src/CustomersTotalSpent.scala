import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkContext


//object wordCount {
//  def main(args: Array[String]) = {}
//}
object customersTotalSpent extends App {
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","wordCount")
  //input - customer ID, Product ID, customer amount
  // 0,1234,14.50
  //output - 0,14.50
  val input = sc.textFile("c:/users/posiva/Desktop/Work/Exxon/BigData/9Week-ApacheSpark _GeneralPurposeClusterComputingFramework/customerorders.csv")
  val mappedInput = input.map(x=>(x.split(",")(0).toInt,x.split(",")(2).toFloat)) //getting only customer ID and amount spent
  //val words = input.map(_.split(","))
  //val mappedInput = words.map(x => (x(0).toInt,x(2).toFloat))
  //input - (0,14.50) (0,20.00) (1,10.00)(1,20.00) -> output (0,34.50) (1,30.00)
  val totalByCustomer = mappedInput.reduceByKey((x,y) => (x+y)) //pair RDD
  val sortedTotal = totalByCustomer.sortBy(x=> x._2,false) //sort by value - amount spent, descending order
  val result = sortedTotal.collect
  println("Output:")
  result.foreach(println)
  /*
  val result1 = resultFinal.collect
  for(i <- result1){
    val key = i._1
    val value = i._2
    println(s"$key : $value")
  }
  * 
  */
  //scala.io.StdIn.readLine()   //this statement is to visualize the DAG
  
}