import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.FloatType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.SaveMode




object MySparkWeek12SparkSql extends App {
  
  println("Entering into Spark")
  //Step 2 - Setting the logging level to Error
  Logger.getLogger("org").setLevel(Level.ERROR)
  
  //creating sparkConf object
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name","MySparkWeek12SparkSql")
  sparkConf.set("spark.master","local[2]")
  
  //Step1 -creating a spark session
  val spark = SparkSession.builder()
              .config(sparkConf)
            //  .enableHiveSupport()  //Hive support - Hive metastore
              .getOrCreate()
  
  // Step 3 Explicit schema definition programmatically using StructType
  val windowDataSchema = StructType(List(
      StructField("Country",StringType,false),
      StructField("Weeknum",IntegerType,true),
      StructField("NumInvoices",IntegerType,true),
      StructField("TotalQuantity",IntegerType,true),
      StructField("Amount",FloatType,true)
      )
      )
      
  // Step 3 contd.. Loading the file and creation of dataframe using dataframe reader API, using explicitly
  //specified schema
    
  val windowDf = spark.read
                 .format("csv")
                 .option("header",false)
                // .option("inferSchema",true)
                 .schema(windowDataSchema)
                 .option("mode","DROPMALFORMED")
                 .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/windowdata.csv")
                 .load
  windowDf.show
  windowDf.printSchema

  
  windowDf.createOrReplaceTempView("windows")
  val resultDf = spark.sql("select country, sum(amount) as total_amount from windows " +
      "group by country order by total_amount")
  resultDf.show()
  
  //to save the data in table format with spark metastore - spark inmemory
  windowDf.write
          .format("csv")
          .mode(SaveMode.Overwrite)
          .saveAsTable("windows1")
  
  spark.sql("create database if not exists retail")
  windowDf.write
          .format("csv")
          .mode(SaveMode.Overwrite)
          .bucketBy(4,"weekNum")
          .sortBy("weekNum")
          .saveAsTable("retail.WindowsHive1")
  spark.catalog.listTables("retail").show()   
  
}




