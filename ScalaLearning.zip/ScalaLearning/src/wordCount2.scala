import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkContext


//object wordCount {
//  def main(args: Array[String]) = {}
//}
object wordCount2 extends App {
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","wordCount")
  val input = sc.textFile("c:/users/posiva/Desktop/Work/Exxon/BigData/search_data.txt")
  val words = input.flatMap(_.split(" "))
  val wordsLower = words.map(_.toLowerCase())
  val keys = wordsLower.map((_,1))
  val result = keys.reduceByKey((_+_))
  val resultTuple = result.map(x=>(x._2,x._1))
  val resultFinal = resultTuple.sortByKey(false).map(x => (x._2, x._1))
  
  //val sortedResults = result.sortBy(x => x._2, false)
  println("Output:")
  //resultFinal.collect.foreach(println)
  val result1 = resultFinal.collect
  for(i <- result1){
    val key = i._1
    val value = i._2
    println(s"$key : $value")
  }
  scala.io.StdIn.readLine()   //this statement is to visualize the DAG
  //Chain  of functions
  //input.flatMap(_.split(" ")).map(_.toLowerCase()).map((_,1)).reduceByKey((_+_)).collect.foreach(println)
  
  
}