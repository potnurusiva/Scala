import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DateType

object MySparkWeek12SparkUDF2 extends App {
  
  println("Entering into Spark")
  //Step 2 - Setting the logging level to Error
  Logger.getLogger("org").setLevel(Level.ERROR)
  
  //creating sparkConf object
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name","MySparkWeek12SparkUDF2")
  sparkConf.set("spark.master","local[2]")
  
  //Step1 -creating a spark session
  val spark = SparkSession.builder()
              .config(sparkConf)
              .getOrCreate()
      
  val myList = List(
      (1,"2013-07-25",11599,"CLOSED"),
      (2,"2014-07-25",256,"PENDING_PAYMENT"),
      (3,"2013-07-25",11599,"COMPLETE"),
      (4,"2019-07-25",8827,"CLOSED")
      )
  
  /*              
  val rdd = spark.sparkContext.parallelize(myList)
  println("Input RDD")
  rdd.collect.foreach(println)
  import spark.implicits._
  val df = rdd.toDF()
  println("Converted DF")
  df.show
  */
  //other way
  val df = spark.createDataFrame(myList)
  println("Dataframe")
  df.show()
  println("Dataframe with column names")
  val df1 = df.toDF("OrderID","OrderDate","CustomerID","OrderStatus")
  df1.show()
  val df2 = df1.withColumn("OrderDate",unix_timestamp(col("OrderDate").cast(DateType)))
  println("Epoch time stamp column")
  df2.printSchema()
  df2.show()
  val df3 = df2.withColumn("NewId", monotonically_increasing_id)
  println("With new column")
  df3.printSchema()
  df3.show
  val df4 = df3.dropDuplicates("orderDate","CustomerId")
  println("With distinct values")
  df4.show()
  val df5 = df4.drop("orderId").sort("orderDate")
  println("Orderid column removed and sorted on orderDate")
  df5.printSchema()
  df5.show()
  val df6 = df5.select("NewId","OrderDate","CustomerId","OrderStatus")
  println("Final - reordered output")
  df6.show()
      
  spark.stop()


}




