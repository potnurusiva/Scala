import org.apache.spark.SparkContext
import org.apache.log4j.Level
import org.apache.log4j.Logger


//object wordCount {
//  def main(args: Array[String]) = {}
//}
object wordCountOnAWS extends App {
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext()
  val input = sc.textFile("s3n://bigdatasiva/book-data.txt")
  val words = input.flatMap(x => x.split(" "))
  val keys = words.map(x => (x,1))
  val result = keys.reduceByKey((a,b) => (a+b))
  println("Output:")
  result.collect.foreach(println)
  //scala.io.StdIn.readLine()   //this statement is to visualize the DAG
}