import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.FloatType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.Column
import org.apache.spark.sql.functions._


object MySparkWeek12SparkStructureToRdd extends App {
  
  println("Entering into Spark")
  //Step 2 - Setting the logging level to Error
  Logger.getLogger("org").setLevel(Level.ERROR)
  
  //creating sparkConf object
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name","MySparkWeek12SparkStructureToRdd")
  sparkConf.set("spark.master","local[2]")
  
  //Step1 -creating a spark session
  val spark = SparkSession.builder()
              .config(sparkConf)
              .getOrCreate()
      
  val myregex = """^(\S+) (\S+)\t(\S+)\,(\S+)""".r 
  //schema
  case class orders(order_id : Int, customer_id : Int, order_status: String)
  //reading unstructured data into rdd
  val lines = spark.sparkContext.textFile("C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\12Week_ApacheSparkStructuredAPIPart2\\orders_new.csv")
  import spark.implicits._
  val ordersDs = lines.map(parser).toDS().cache()
  def parser(line: String) = {
    line match {
      case myregex(order_ids,dates,customer_ids,order_statuss) =>
        orders(order_ids.toInt, customer_ids.toInt, order_statuss)
    }
  }
  
  ordersDs.printSchema()
  ordersDs.select("order_id").show()
  ordersDs.groupBy("order_status").count().show()
  ordersDs.filter(x =>x.customer_id > 100).show()
  
  //Refer a column from DS/DF  
  import spark.implicits._
  ordersDs.select(column("order_id"),col("customer_id"),$"order_status",'order_id).show()
  
  spark.stop()


}




