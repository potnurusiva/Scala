object MyThird extends App{
  /*Diamond problem 
  //Class - multi inhertiance is not possible with classes
  //Solution- trait
  trait traitA {
    def name = println("This is grand Parent")
  }
  trait traitB extends traitA {
    override def name = {println("This is B")
    super.name
    }
  }
  trait traitC extends traitA {
    override def name = {println("This is C")
    super.name
    }
  }
  object grandChildren extends traitB with traitC
  grandChildren.name
  
  */
  //Exception Handling
  try{
    val b = 5/0
  }
  catch{
    case e: Exception => println("Please give denominator other than zero")
  }
  finally {
    println("I will always execute irrespective of the exception")
  }
  
  //Monad
  val list1 = List(1,2,3,4)
  val list2 = List(5,6,7,8)
  for ( i <- list1) println(list2.map( y => i+y))
  
  println(list1.map(x => list2.map(y => x+y)))
  println(list1.flatMap(x => list2.map(y => x+y)))
  
  
  
  //Streams in Scala
  //Lazy Lists
  val l = List(1,2,3,4)
  val l1 = 100 :: 200 :: 300 :: 400 :: Nil    //List definition another way
  println(l)
  println(l1)
  
  val l2 = Stream(10,20,30,40)
  val l3 = 15 #:: 30 #:: 45 #:: 60 #:: Stream.empty
  println(l2)
  println(l3)
  l2.take(2).print
  l3.take(5).print
  
  //ofDim  - multi dimensional Arrays
  println("ofDim - multi dimensional Arrays")
  val myA1 = Array.ofDim[Int](2,2)
  for ( i <- 0 to 1; j <- 0 until 2) println(myA1(i)(j))
  myA1(0)(0) = 2
  myA1(0)(1) = 3
  myA1(1)(0) = 5
  myA1(1)(1) = 6
  for ( i <- 0 to 1; j <- 0 until 2) println(myA1(i)(j))
  for ( i <- 0 to 1; j <- 0 until 2) println(i,j)
   
  
  
  
 }