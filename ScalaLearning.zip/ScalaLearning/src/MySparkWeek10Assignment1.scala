import org.apache.spark.SparkContext
import org.apache.log4j.Level
import org.apache.log4j.Logger
import scala.io.Source
import breeze.linalg.sum

object MySparkWeek10Assignment1 extends App{
  
  
  println("Entering here")
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","MySparkWeek10Assignment1")
  //load chapters file
  val chapterRdd = sc.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/10Week_ApacheSpark_inDepth/AssignmentDatasets/chapters.csv")
  //input chapterId courseId, output Rdd- chapterId, courseId
  val chapterFieldsRdd = chapterRdd.map(x => {
    val chapterDataFields = x.split(",")
    (chapterDataFields(0).toInt,chapterDataFields(1).toInt)
  })
      
  //Load views files
  val viewsDataRdd = sc.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/10Week_ApacheSpark_inDepth/AssignmentDatasets/views-*.csv")
  //input - userId, chapterId, dateTime
  //output - userId, chapterId
  val viewsMappedRdd = viewsDataRdd.map(x => (x.split(",")(0).toInt, x.split(",")(1).toInt))
  
  //Load title files
  val titlesDataRdd =sc.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/10Week_ApacheSpark_inDepth/AssignmentDatasets/titles.csv")
  //input - courseId, title 
  //output - courseId, title
  val titlesMappedRdd = titlesDataRdd.map(x => (x.split(",")(0).toInt, x.split(",")(1)))
  
  //Find Out how many Chapters are there per course
  //Exercise 1 - count total of chapters in each course
  //input - chapterId courseId , output - courseId,1
  val chapterMappedRdd = chapterRdd.map(x => (x.split(",")(1).toInt, 1))
  //input - courseId,1
  //output - courseId, totalCount of chapters
  //chapterMappedRdd.countByKey().foreach(println)
  val chapterCountRdd = chapterMappedRdd.reduceByKey((x,y) => (x+y)).sortBy(x => x._1)
  println("Exercise 1")
  chapterCountRdd.collect().foreach(println)  
  //scala.io.StdIn.readLine()
  
  //Exercise 2
  //Removing Duplicate Views from views RDD 
  println("Exercise 2")
  val viewsDistinctRdd = viewsMappedRdd.distinct()
  //Need to join to get the chapterId, courseId, userId mapping
  //Before join, keys should be same in both RDDs
  //chapterFieldsRdd - chapterId, courseId
  //viewsDistinctRdd - userId, chapterId
  //so need to swap the key, values in viewsDistinctRdd to get the chapterId, userId
  val viewsDistinctFlipRdd = viewsDistinctRdd.map(x => (x._2,x._1))
  //Join viewsDistinctFlipRdd with chapterFieldsRdd
  //Input - chapterId, userId  join  chapterId, courseId
  //output - chapterId, userId, courseId
  val joinRdd = viewsDistinctFlipRdd.join(chapterFieldsRdd)
  
  
  //Dropping off the chapterIds and appending 1 as the value 
  //input (chapterId, (userId,courseId))
  //output ((userId, courseId),1))
  //It's useful to check how many times a user entered the same course irrespective of the chapter in the course
  val pairRdd = joinRdd.map(x => ((x._2._1,x._2._2), 1))
  //Count Views for User/Course -Finding out count
  //of number of chapters a user has watched per course
  //input ((userId, courseId),1))
  //output ((userId, courseId),totalCountOfViews))
  val userPerCourseViewRdd = pairRdd.reduceByKey(_+_)
  
  //Remove the userId now
  //Dropping the UserID going forward
  //input ((userId, courseId),totalCountOfViews))
  //output (courseId, totalCountOfViews)
  val courseViewsCountRdd = userPerCourseViewRdd.map(x => (x._1._2,x._2))
  
  //Join the chapterCountRDD with courseViewsCountRDD
  //to integrate total chapters in a course
  //input - (courseId, totalCountOfViews) join (courseId, totalCount of chapters)
  //output - (courseId, (totalCountOfViews,totalCount of chapters))
  val newJoinRdd = courseViewsCountRdd.join(chapterCountRdd)
  
  // Calculating Percentage of course completion
  //input - (courseId, (totalCountOfViews,totalCount of chapters))
  //output - (courseId, percentageCompletionOfTheCourse)
  val courseCompletionRdd = newJoinRdd.mapValues( x => (x._1.toDouble/x._2))
  //formatting the RDD output
  val formattedPercentageRdd = courseCompletionRdd.mapValues(x => f"$x%09.5f".toDouble)
  println("formattedPercentageRdd")
  formattedPercentageRdd.collect().foreach(println)
  
  //Map percentages to scores as per business rules
  //input - (courseId, percentageCompletionOfTheCourse)
  //output -(courseId, score)
  val scoresRdd = formattedPercentageRdd.mapValues(x => {
    if (x >= 0.9) 10l
    else if (x >= 0.5 && x < 0.9) 4l
    else if (x >= 0.25 && x < 0.5) 2l
    else 0l
  })
  
  //Adding up all total scores for a course
  //input -(courseId, score)
  //output -(courseId, totalScoreOfTheCourse)
  val totalScoresPerCourseRdd = scoresRdd.reduceByKey(_+_)
  totalScoresPerCourseRdd.collect().foreach(println)
  
  //Exercise 3
  //Associate Titles with Courses and getting rid of courseIDs 
  println("Exercise-3")
  //input (courseId, totalScoreOfTheCourse) join (courseId, title)
  //output (courseId, (totalScoreOfTheCourse, title))
  //formatted output with map - (totalScoreOfTheCourse, title)
  val titleScoreJoniedRdd = totalScoresPerCourseRdd.join(titlesMappedRdd).map( x => (x._2._1,x._2._2)) 
  
  //Displaying courses starting with the most popular course 
  val popularCourseRdd = titleScoreJoniedRdd.sortByKey(false)
  popularCourseRdd.collect().foreach(println)
  
  //scala.io.StdIn.readLine()
  
 
}
