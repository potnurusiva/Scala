import org.apache.spark.SparkContext
import org.apache.log4j.Level
import org.apache.log4j.Logger
import scala.math.min

object MyFifthPractical2 extends App{
  
  //Minimum temperatures
  println("Entering here")
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","MyFifthPractical2")
  val file = sc.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/9Week-ApacheSpark _GeneralPurposeClusterComputingFramework/tempdata.csv")
  val line = file.map(x => (x.split(",")(0),x.split(",")(2),x.split(",")(3)))
  //line.collect.foreach(println)
  val minTemps = line.filter(x => x._2 == "TMIN")
  //minTemps.collect.foreach(println)
  val stationTemps = minTemps.map(x => (x._1, x._3.toFloat))
  //stationTemps.collect.foreach(println)
  val minStationTemps = stationTemps.reduceByKey((x,y) => min(x,y))
  val result = minStationTemps.collect
  for ( i <- result.sorted) {
    val station = i._1
    val temp = i._2
    println(s"$station minimum temperature is: $temp")
  }
}
