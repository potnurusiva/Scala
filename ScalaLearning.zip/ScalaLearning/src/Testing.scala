import org.apache.spark.SparkContext
import org.apache.log4j.Level
import org.apache.log4j.Logger
import scala.math.min
import scala.math.max

object Testing extends App{
  println("Welcome")
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","Testing")
  
  val input = Seq((1,54),(1,523),(1,5412),(1,678),(1,322))
  val rdd1 = sc.parallelize(input)
  rdd1.collect.foreach(println)
  val rdd2 = rdd1.reduceByKey((x,y)=> (if (x>y) x else y))
  println("1. Maximum value for the given key : ")
  rdd2.collect.foreach(println)
  println("2. Maximum value for the given key : ")
  val rdd3 = rdd1.reduce((x,y) => (if(x._2>y._2)x else y))
  println(rdd3)
  println("3. Maximum value for the given key : ")
  val rdd4 = rdd1.reduceByKey((x,y) => max(x,y))
  rdd4.collect.foreach(println)
  
  /*
  val input = sc.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/9Week-ApacheSpark _GeneralPurposeClusterComputingFramework/dataset1.txt")
  /*
  val output = input.map(x => {if (x.split(",")(1).toInt > 18)
                                 (x.split(",")(0),x.split(",")(1),x.split(",")(2),"Y")
                              else
                                 (x.split(",")(0),x.split(",")(1),x.split(",")(2),"N") 
  } )  
  output.collect.foreach(println)
  * */            
  val output1 = input.map(x => {val fields = x.split(",")
                               if ((fields(1).toInt) > 18)
                                 (fields(0),fields(1),fields(2),"Y")
                               else
                                 (fields(0),fields(1),fields(2),"N")
                                })
  output1.collect.foreach(println)
  
  */
}