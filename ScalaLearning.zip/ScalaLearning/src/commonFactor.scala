object commonFactor extends App {
  println("CommonFactor")
  println("Enter first integer a \n")
  val a: Int = scala.io.StdIn.readInt()
  println("Enter Second integer b \n")
  val b: Int = scala.io.StdIn.readInt()
  var result:List[Int] = List()
  var count = 0
  for(i <-  1 to b){
    if(a%i == 0 && b%i == 0){
      count = count + 1
      result = i :: result
      }
  }
  println(s"$a and $b have $count common factors")
  println("common factors are :" + result.mkString(","))
}