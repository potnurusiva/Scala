import org.apache.spark.SparkContext
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Seconds
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.DateType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import scala.collection.JavaConversions._
import org.apache.spark.sql.Row


object interviewQuestion extends App{
  
  Logger.getLogger("org").setLevel(Level.ERROR)
  //create spark context
  val sc = new SparkContext("local[*]","MySparkWeek15StreamingWordCount")
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name","interviewQuestion")
  sparkConf.set("spark.master","local[*]")
  
  val spark = SparkSession.builder()
                          .config(sparkConf)
                          .getOrCreate();
  
  val publishData = List(Row("P1",10,"10/11/2020"),
                         Row("P2",15,"01/11/2020"),
                         Row("P3",20,"16/11/2020"),
                         Row("P5",30,"16/11/2020"))
                         
  val stageData   = List(Row("P2",20,"16/11/2020"),
                         Row("P3",25,"17/11/2020"),
                         Row("P4",10,"10/11/2020"),
                         Row("P2",22,"17/11/2020"),
                         Row("P1",15,"17/11/2020"),
                         Row("P5",20,"10/11/2020"))
 val publishSchema = StructType(List(StructField("ProdName",StringType),
                                     StructField("Price",IntegerType),
                                     StructField("Date",StringType)
                                     ))
                                     
 val stageSchema = StructType(List(StructField("ProdName1",StringType),
                                     StructField("Price1",IntegerType),
                                     StructField("Date1",StringType)
                                     ))
                                     
 val publishDf  =  spark.createDataFrame(publishData,publishSchema)
 //.toDF("ProdName","Price","Date")
 println("publishDf")
 publishDf.show()
 val stageDf    =  spark.createDataFrame(stageData,stageSchema)
 //.toDF("ProdName1","Price1","Date1")
 println("stageDf")
 stageDf.show()
 
 val joinCondition = publishDf.col("ProdName")===stageDf.col("ProdName1")
 val joinType = "right"
 
 val joinDf = publishDf.join(stageDf,joinCondition,joinType)
 println("joinDf")
 joinDf.show
 
 joinDf.createOrReplaceTempView("JoinTable")
 val resultDf = spark.sql("""select ProdName1, Price1, Date1 from 
             (select ProdName1, Price1, Date1, dense_rank()
             over(partition by ProdName1 order by Date1 desc) as rank
             from JoinTable)
             where rank = 1""")
 println("resultDf")
 resultDf.show
 
 println("Union Model - best approach")
 val unionDf =  publishDf.unionAll(stageDf)
 println("unionDf")
 unionDf.show
 unionDf.createOrReplaceTempView("UnionTable")
 val result1Df = spark.sql("""select ProdName, Price, Date from 
             (select ProdName, Price, Date, dense_rank()
             over(partition by ProdName order by Date desc) as rank
             from UnionTable)
             where rank = 1 order by ProdName""")
 println("result1Df")
 result1Df.show 
}