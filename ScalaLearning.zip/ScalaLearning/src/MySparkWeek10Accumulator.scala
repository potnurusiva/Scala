import org.apache.spark.SparkContext
import org.apache.log4j.Level
import org.apache.log4j.Logger
import scala.io.Source

object MySparkWeek10Accumulator extends App{
  
  //calculating the total cost incurred for searching a word
  println("Entering here")
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","MySparkWeek10Accumulator")
  //input
  //Lines
  val myRdd = sc.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/10Week_ApacheSpark_inDepth/samplefile.txt")
  val myAccum = sc.longAccumulator("BlankLineAccumulator")
  myRdd.foreach(x=> if(x == "") myAccum.add(1))
  println(myAccum.value)
  scala.io.StdIn.readLine()
}
