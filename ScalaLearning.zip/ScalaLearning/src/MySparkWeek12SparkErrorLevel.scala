import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

object MySparkWeek12SparkErrorLevel extends App {
  
  println("Entering into Spark")
  //Step 2 - Setting the logging level to Error
  Logger.getLogger("org").setLevel(Level.ERROR)
  
  //creating sparkConf object
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name","MySparkWeek12SparkErrorLevel")
  sparkConf.set("spark.master","local[2]")
  
  //Step1 -creating a spark session
  val spark = SparkSession.builder()
              .config(sparkConf)
              .getOrCreate()
              

  /*
  //First we can use the sample data
  val myList = List("DEBUG,2015-2-6 16:24:07",
                    "WARN,2016-7-26 18:54:43",
                    "INFO,2012-10-18 14:35:19",
                    "DEBUG,2012-2-26 14:26:50",
                    "DEBUG,2013-9-28 20:27:13",
                    "INFO,2017-8-20 13:17:27")
                    
  val rdd1 = spark.sparkContext.parallelize(myList)
  //rdd1.collect.foreach(println)
  val rdd2 = rdd1.map(mapper)  
  import spark.implicits._
  val df1 = rdd2.toDF()
  println("input data frame")
  df1.show()
  
  case class Logging (level:String,datetime: String)
  def mapper(line:String):Logging = {
    val fields = line.split(',')
    val logging: Logging = Logging(fields(0),fields(1))
    return logging
  }
   
  //Create a temporary table and execute queries on it
  df1.createOrReplaceTempView("logging_table")
  println("table - logging_table")
  spark.sql("select * from logging_table").show
  
  println("some aggregate functions")
  spark.sql("""select level, first(datetime),count(datetime),
              collect_list(datetime) from logging_table 
               group by level
               order by level""").show(false)
  
  val df2 = spark.sql("""select level,
                      date_format(datetime,'MMMM') as Fullmonth,
                      date_format(datetime,'MM') as numbermonth,
                      date_format(datetime,'MMM') as halfmonth
                      from logging_table""") 
  println("date formats")
  df2.show
  
  val df3 = df2.select("level", "fullmonth")
  df3.createOrReplaceTempView("new_logging_table")
  println("new logging table")
  spark.sql("select * from new_logging_table").show()
  
  println("Error level count")
  spark.sql("""select level,fullmonth,count(1) 
               from new_logging_table 
               group by level,fullmonth """).show()             
  
  
    */       
  val logsDf = spark.read
                .format("csv")
                .option("header",true)
                .option("inferSchema",true)
                .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\12Week_ApacheSparkStructuredAPIPart2\\biglog.txt")
                .option("mode","DROPMALFORMED")
                .load()
                
  
  println("logsDf")
  //logsDf.show
  
  val df4 = logsDf.createOrReplaceTempView("my_new_logging_table")
  println("my_new_logging_table")
  spark.sql("""select level, date_format(datetime,'MMMM') as month,
             count(1) as total,count(level) as totalSum from my_new_logging_table
             group by level, month
             order by month""").show(100)
   
  println("result table")           
  val result1 = spark.sql("""select level,date_format(datetime,'MMMM') as month,
                          cast(first(date_format(datetime,'MM')) as INT) as monthnum,
                          count(1) as total from my_new_logging_table
                          group by level,month
                          order by monthnum, level""")
  //result1.show(100)                        
                          
  val result2 = result1.drop("monthnum")
  result2.show(100)
  
  
  //PIVOT Table
  println("PIVOT table")
  val result3 = spark.sql("""select level,date_format(datetime,'MMMM') as month,
                          cast(date_format(datetime,'MM') as INT) as monthnum
                          from my_new_logging_table""")
                          .groupBy("level")
                          .pivot("monthnum")
                          .count()
                          
  result3.show    
  
  
  //Pivot table with  month names
  println("Pivot table with month names")
  val columns = List("January","February","March","April","May","June",
                     "July","August","September","October","November","December")
                     
  val result = spark.sql("""select level,date_format(datetime,'MMMM') as month
                          from my_new_logging_table""")
                          .groupBy("level")
                          .pivot("month",columns)
                          .count()
  println("Final result")
  result.show
                       
  //scala.io.StdIn.readLine()  
  spark.stop()
  
}




