import org.apache.spark.SparkContext
import org.apache.log4j.Level
import org.apache.log4j.Logger

object MyFifthPractical extends App{
  
  //adding Y or N
  println("Entering here")
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","MyFifthPractical")
  val file = sc.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/9Week-ApacheSpark _GeneralPurposeClusterComputingFramework/dataset1.txt")
  /*val line = file.map(x => { 
    val fields = x.split(",")
    if(fields(1).toInt > 18)
      (fields(0),fields(1),fields(2),"Y")
    else
      (fields(0),fields(1),fields(2),"N")     
  }
  )  
  */
  
  val line = file.map(x => x.split(","))
  val output = line.map(x => if(x(1).toInt > 18) 
                                (x(0),x(1),x(2),"Y")
                             else
                                (x(0),x(1),x(2),"N"))
  output.collect().foreach(println)
  
}
