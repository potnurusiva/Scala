import org.apache.spark.SparkContext
import org.apache.log4j.Level
import org.apache.log4j.Logger
import scala.io.Source
import breeze.linalg.sum

object MySparkWeek11TopMovies extends App{
  
  
  println("Entering here")
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","MySparkWeek10Assignment1")
  //load ratings file
  val ratingRdd = sc.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/ratings.dat")
  //input userId::movieId::rating::Timestamp(EPOC Time), output Rdd- movieId, rating
  val ratingMappedRdd = ratingRdd.map(x => {
    val ratingDataFields = x.split("::")
    (ratingDataFields(1).toInt,ratingDataFields(2).toInt)
  })
  //(1193,5)
  //(1193,3)
  //(1194,2)
      
  //to find the average rating of a movie
  //input Rdd- (movieId, rating)
  //output Rdd - (movieId, (rating,1))
  val newMappedRdd = ratingMappedRdd.mapValues( x => (x.toFloat,1.0) ) // (1193,(5.0,1.0)),(1193,(3.0,1.0)),(1194,(2.0,1.0))
  //count the total rating and total numbers of ratings given
  val reduceRdd = newMappedRdd.reduceByKey((x,y) => (x._1+y._1, x._2+y._2)) //(1193, (8.0,2.0)),(1194,(2.0,1.0))
  //Criteria is atleat 1000 users have given the rating and the rating is greater than or equal to 4.5
  val filterRdd = reduceRdd.filter(x => x._2._2 >= 1000)
  val ratingsRdd = filterRdd.mapValues(x => x._1/x._2).filter(x => x._2 >= 4.5)
  val ratingsFormattedRdd = ratingsRdd.mapValues( x => f"$x%01.2f")
  //(movieId, rating)
  //ratingsFormattedRdd.collect.foreach(println)
  
  //load movies file , input -movieId::movieName::category of the movie
  //output - movieId, movieName
  val movieRdd = sc.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/movies.dat")
  val movieMappedRdd = movieRdd.map(x => (x.split("::")(0).toInt,x.split("::")(1)))
  val movieBroadcastedRdd = sc.broadcast(movieMappedRdd.collect.toList.toMap)
  //println("movieBroadcastedRdd " + movieBroadcastedRdd.value(0))
  println("Broadcasted Way")
  
  val moviewithnameRdd = ratingsFormattedRdd.map(x => {
    val movieId = x._1
    val movieRating = x._2
    val movieName = movieBroadcastedRdd.value(movieId)
    (movieName,movieRating)
  })
  moviewithnameRdd.collect.foreach(println)
  //Join to get the (movieId, (rating,movieName))
  println("Join Way")
  val joinRdd = ratingsFormattedRdd.join(movieMappedRdd)
  val finalRdd = joinRdd.map(x => (x._2._2,x._2._1))
  finalRdd.collect.foreach(println)
  scala.io.StdIn.readLine()
  
  
}
