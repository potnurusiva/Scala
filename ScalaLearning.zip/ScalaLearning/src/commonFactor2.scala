import scala.io.StdIn.readInt
import scala.io.StdIn.readLine
import scala.util.control.Breaks._
import scala.util.control.Breaks.break

object commonFactor2 extends App {
  println("Enter size of the array")
  var input1: Int = readInt() // Reading input from STDIN
  val maxNum = 100000
  while (input1 < 1 | input1 > 100000) {
    println("Enter proper size of the array \n")
    var input2: Int = readInt()
    input1 = input2
    println("input1: " + input2)
  }
  println("Hi, input1 :" + input1) // Writing output to STDOUT
  println("Enter array of elements")
  val input3: String = readLine() // Reading input from STDIN
  println("Hi, input3 :" + input3) // Writing output to STDOUT
  var input: Array[Int] = input3.split(" ").map(x => x.toInt)
  print("Hi, input : \n")
  for( i <- input) println(i)

  while (input.length != input1) {
    println("Enter no. of array elements equal to previous input1 ")
    val input4: String = readLine()
    input = input4.split(" ").map(x => x.toInt)
    print("Hi, while input :\n" )
    for( k <- input) println(k)
  }

  val inputSum = input.sum
  println("inputSum :" + inputSum)
  var result = 0
  breakable {
    for (i <- 1 to maxNum) {
      for (j <- 0 to input1 - 1) {
        input(j) = i;
      }
      if (input.sum > inputSum) {result = input(0);break}
    }
  }
  println("least Value we can replace is :" + result)
}