import org.apache.spark.SparkContext
import org.apache.log4j.Level
import org.apache.log4j.Logger
import scala.io.Source

object MySparkWeek10BoringWords extends App{
  
  //calculating the total cost incurred for searching a word
  println("Entering here")
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","MySparkWeek10BoringWords")
  //loading the boring words file locally
  def loadBoringWords(): Set[String] = {
    var boringWords: Set[String] = Set()
    val lines = Source.fromFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/10Week_ApacheSpark_inDepth/boringwords.txt").getLines()
    for (line <- lines) {
      boringWords += line
    }
    boringWords
  }
  //broadcasting the local file - boringwords to all machines
  val nameSet =  sc.broadcast(loadBoringWords)
  
  //input
  //search terms,matching,.......,avg.cost, cost ==>big data contents,match,....,24.09
  val initialRdd = sc.textFile("C:/Users/posiva/Desktop/Work/Exxon/BigData/10Week_ApacheSpark_inDepth/bigdatacampaigndata.csv")
  //output
  //cost, search terms ==> 24.09, big data contents
  val mappedInput = initialRdd.map(x => (x.split(",")(10).toFloat,x.split(",")(0)))
  //input 24.09,big data contents
  //output 24.09 big
  //       24.09 data
  //       24.09 contents
  val words = mappedInput.flatMapValues(x => x.split(" "))
  //swap the key value pair
  val finalMapped = words.map(x => (x._2.toLowerCase,x._1))
  //Filter the words which are not in boring wirds list
  val filteredRdd = finalMapped.filter(x => !nameSet.value(x._1))
  //total the value of cost
  val total = filteredRdd.reduceByKey((x,y) => (x+y))
  val sorted = total.sortBy(x => x._2, false) //sort the data in descending order
  sorted.take(20).foreach(println)
  
}
