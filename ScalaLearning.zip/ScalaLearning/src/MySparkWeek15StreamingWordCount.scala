import org.apache.spark.SparkContext
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Seconds
import org.apache.log4j.Level
import org.apache.log4j.Logger


object MySparkWeek15StreamingWordCount extends App{
  
  Logger.getLogger("org").setLevel(Level.ERROR)
  //create spark context
  val sc = new SparkContext("local[*]","MySparkWeek15StreamingWordCount")
  
  //Create spark stream context
  val ssc = new StreamingContext(sc, Seconds(5))
  
  //lines is a Dstream - gets the input from socket create by using nc -lk 9998
  val lines = ssc.socketTextStream("localhost", 9998)
  
  //words is a transformed Dstream
  val words = lines.flatMap(x => x.split(" "))
  
  //
  val pairs = words.map(x => (x,1))
  
  val wordCounts = pairs.reduceByKey((x,y) => (x+y))
  
  wordCounts.print
  
  ssc.start()
  ssc.awaitTermination()
  //reduceByKey() --State less transformation
  //updateStateByKey() --State full transformation
  //reduceByKeyAndWindow() --State full transformation
  //countByWindow() --State full transformation
  //reduceByWindow() --State full transformation
  
}