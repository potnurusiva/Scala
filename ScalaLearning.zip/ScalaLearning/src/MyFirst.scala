

object MyFirst extends App{
  /*
  //default argumnets
  def add(num:Int, incrementBy:Int) = { num + incrementBy}
  println("Normal function")
  println(add(5,6))
  
  def add1(num:Int = 8, incrementBy:Int = 1) = { num + incrementBy} //default args
  println("Function with default arguments")
  println(add1())
  println(add1(5))
  println(add1(5,10))
  println(add1(num = 20, incrementBy = 30)) //named args
  
  def printIn(name: String*) = {    //variable args
    for(i <- name) println(i)
  }
  println("Function with variable arguments")
  printIn("Hello","How","are","you")
  printIn("Hello","Hai")
  
  //Null, null
  def tryIt(thing: Null): Unit = {println("Hello work")}
  //println(tryIt("Sumit"))
  tryIt(null)
  
  //Nil
  val c = Nil
  val d =10::c
  println(c)
  
  //Nothing
  def fun = {
    throw new Exception
  }
  fun
  
  //Option  - Some or None
  def getAStringMayBe(num: Int) : Option[String] = {
    if(num>=0) Some("A Positive Number!")
    else None
  }
  def printResult(num: Int) = {
    getAStringMayBe(num) match {
      case Some(str1) => println(str1)
      case None => println("No String")
    }
  }
  printResult(10)
  printResult(-10)
  
  //Unit
  def funcNew = { println("Hello World! - return type is Unit")}
  funcNew
  
  //None
  println(None.toList)
  println(None.isEmpty)
  println(None.toString())
  val p: Option[String] = None
  println(p)
  
  
  //Handling Null pointer exception
  case class Address(city: String, state: String, zipcode: String)
  //
  //below code throws null pointer exception
  class Users(email:String,password:String) {
    var firstName: String = "Siva"
    var lastName: String = _
    var address: Address = _
  }
  val user1 = new Users("siva@123.com","abcd")
  println(user1.firstName.length)
  //println(user1.lastName.length)
  
  
  
  case class User(email:String,password:String) {
    var firstName: Option[String] = None
    var lastName: Option[String] = None
    var address: Option[Address] = None
  }
  val usr1 = new User("siva@123.com","abcd")
  //println(usr1.firstName.toString.length)
  //println(usr1.lastName.toString.length)
  println(usr1.firstName.getOrElse("<Not assigned>"))
  println(usr1.lastName.getOrElse("<Not assigned>"))
  println(usr1.address.getOrElse("<Not assigned>"))
  
  usr1.firstName = Some("Siva")
  usr1.lastName = Some("123")
  usr1.address = Some(Address("Bangalore","Karnataka","560037"))
  println(usr1.firstName.getOrElse("<Not assigned>"))
  println(usr1.lastName.getOrElse("<Not assigned>"))
  println(usr1.address.getOrElse("<Not assigned>"))
  println(usr1.email)
  println(usr1.password)
  
  
  
  val a = for(i<- 1 to 10) {i*i}
  println("a :" +a)
  
  //yield
  val b = for(i<- 1 to 10) yield{(i*i)}
  println("b :" +b)
  
  //if in yield statement
  val c = for(i<- 1 to 10) yield { if (i % 2==0) i*i }
  println("c :" +c)
  
  //if guard
  val d = for(i<- 1 to 10; if i%2 == 0) yield { i*i }
  println("d :" +d)
  
  //another syntax
  val e = for{
    i<- 1 to 10
    if i % 2 ==0
  }
  yield i*i
  println("e :"+e)
  
  //Pattern guards
  def checkSign(x: Int) : String = {
    x match {
      case a if a > 0 => s"$a is positive"
      case b if b < 0 => s"$b is negative"
      case c => s"$c is zero"
    }
  }
  println(checkSign(10))
  println(checkSign(-15))
  println(checkSign(0))  
  */
  def f(x: Option[Int]) = {
    x match {
      case Some(i) if i %2 == 0 => println(i)
      case None => println("None")
      case _ => println("Something else")
    }
  }
  f(Some(4))
  f(Some(15))
  f(None)
  
  //for comprehensions
  for(i <- 1 to 10) println(i*i)
  (1 to 10).foreach(i =>println(i*i))// Scala internally converts the above statement as this
  
  val f = for(i <- 1 to 10) yield i*i; println(f)
  val g = (1 to 10).map( i => i*i); println(g)
  
  
  //Inner loops
  val h = for(i <- 1 to 10; j <- 'a' to 'c') yield i*2 + "" + j
  println(h)
  
  
  val i = new String("Siva")
  val j = new String("Siva")
  println( i == j)
  println( i.equals(j))
  println(i equals j)
  println(i.==(j))
  println(i.eq(j)) //to compare the referrences
  println(i eq j)

 }