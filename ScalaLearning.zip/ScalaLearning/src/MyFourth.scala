//Design patterns
//1. Factory design pattern
object MyFourth extends App{
  
  trait Computer {
    def ram: String
    def hdd: String
    def cpu: String
  }
  
  case class PC(ram: String, hdd: String, cpu: String) extends Computer
  case class LAPTOP(ram: String, hdd: String, cpu: String) extends Computer
  
  object ComputerFactory {
    def apply(compType: String, ram: String, hdd: String, cpu: String) = 
      compType match{
                      case "PC" => {PC(ram,hdd,cpu); println("New PC")}
                      case "LAPTOP" => {LAPTOP(ram,hdd,cpu);println("New Laptop")}
                    }
  } 
    ComputerFactory("PC","16GB","1TB","2.3GHZ")
    ComputerFactory("LAPTOP","16GB","1TB","2.3GHZ")
  
  
 }