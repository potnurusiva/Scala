import org.apache.spark.SparkContext
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Seconds
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.types.LongType



object MySparkWeek16StructuredStreamingJoinStreamWithStaticDF extends App{
  
  Logger.getLogger("org").setLevel(Level.ERROR)
  //create spark session
  println("Welcome to Structured Streaming")
  val spark = SparkSession.builder()
              .master("local[2]")
              .appName("MySparkWeek16StructuredStreamingJoinStreamWithStaticDF")
              .config("spark.sql.shuffle.partitions",2)
              .config("spark.streaming.stopGracefullyOnShutdown","true")
           //   .config("spark.sql.streaming.schemaInference","true")
              .getOrCreate()
  
   
  val transactionsSchema = StructType(List(StructField("card_id", LongType),
                                     StructField("amount", IntegerType),
                                     StructField("postcode", IntegerType),
                                     StructField("pos_id", LongType),
                                     StructField("transaction_dt", TimestampType))) 
  
  val transactionsDf = spark.readStream
                      .format("json")
  .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\16Week_ApacheSparkStreamingPart-2\\CardTransactionsInputStream")
                     // .option("inferSchema",true)
                      .option("maxFilesPerTrigger",1)
                     .schema(transactionsSchema)
                     .load()
                     
  //when we use socket as datasource
  //val valueDf = transactionsDf.select(from_json(col("value"),transactionsSchema).alias("value"))                    
  
  //transactionsDf.printSchema() 
  
  val membersDf = spark.read
                      .format("csv")
                      .option("header",true)
                      .option("inferSchema",true)
  .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\16Week_ApacheSparkStreamingPart-2\\memberDetails.txt")
                      .load()
                      
  
  //joining stream with static                    
  val joinCondition = transactionsDf.col("card_id") === membersDf.col("card_id")
  val joinType      = "leftouter" //"leftouter", "rightouter" , "inner"
  
  val enrichedDf = transactionsDf.join(membersDf,joinCondition,joinType)
                                 .drop(membersDf.col("card_id"))
  
  //write output to the sink 
  val resultQuery = enrichedDf.writeStream
                     .format("console")
                     .outputMode("update") //update, append
                     .option("checkpointLocation","checkpointLocation_1")
                   //.option("cleanSource","delete")
                      .option("cleanSource","archive")
                      .option("sourceArchiveDir","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\16Week_ApacheSparkStreamingPart-2\\OrdersArchiveStream") 
                      .trigger(Trigger.ProcessingTime("2 Seconds"))
                     .start()
  resultQuery.awaitTermination()
                     
  
}