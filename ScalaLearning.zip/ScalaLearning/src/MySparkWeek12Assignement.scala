import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._



object MySparkWeek12Assignement extends App {
  
  println("Entering into Spark")
  //Step 2 - Setting the logging level to Error
  Logger.getLogger("org").setLevel(Level.ERROR)
  
  //creating sparkConf object
  val sparkConf = new SparkConf()
  sparkConf.set("spark.app.name","MySparkWeek12Assignement")
  sparkConf.set("spark.master","local[2]")
  
  //Step1 -creating a spark session
  val spark = SparkSession.builder()
              .config(sparkConf)
              .getOrCreate()
              
  
  val employeeDf = spark.read
                        .format("json")
                        .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\12Week_ApacheSparkStructuredAPIPart2\\employee.json")
                        .load()
  println("Employee data")
  employeeDf.show(false)
  employeeDf.createOrReplaceTempView("emp_table") 
  
  val deptDf     = spark.read
                        .format("json")
                        .option("path","C:\\Users\\posiva\\Desktop\\Work\\Exxon\\BigData\\12Week_ApacheSparkStructuredAPIPart2\\dept.json")
                        .load()                      
  println("Department data")
  deptDf.show   
  deptDf.createOrReplaceTempView("dept_table") 
  
  val joinDf1 = deptDf.join(employeeDf, deptDf.col("deptid") === employeeDf.col("deptid"), "left")
  joinDf1.show(false)
  joinDf1.groupBy(deptDf.col("deptid"))
         .agg(count("id") as "emp_count", first("deptname").as("departmentname"))
         .sort("deptid")
         .show()
   
   println("SPARK SQL")       
  joinDf1.createOrReplaceTempView("join_table")
  spark.sql("""select d.deptid,
                first(d.deptname) as departmentname,
                count(e.id) as emp_count
                from dept_table d left outer join  emp_table e 
                on d.deptid = e.deptid
                group by d.deptid order by d.deptid""").show()
  
  
  //scala.io.StdIn.readLine()  
  spark.stop()
  
}




