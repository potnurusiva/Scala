import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkContext


//object wordCount {
//  def main(args: Array[String]) = {}
//}
object avgConnections extends App {
  Logger.getLogger("org").setLevel(Level.ERROR)
  val sc = new SparkContext("local[*]","wordCount")
  //input - row_id,name,age,connections
  //0::siva::25::100
  //output - (25,100)
  val input = sc.textFile("c:/users/posiva/Desktop/Work/Exxon/BigData/9Week-ApacheSpark _GeneralPurposeClusterComputingFramework/friendsdata.csv")
  val mappedInput = input.map(parseLine) //getting only ratings
  def parseLine(line:String) = {
    val fields = line.split("::")
    val age = fields(2).toInt
    val numOfFriends = fields(3).toInt
    (age,numOfFriends)
  }
  //input (25,100) (30,200) (25,100) (30,100) -> output (25,(100,1)) (30,(200,1)) (25,(100,1)) (30,(100,1))
  //val mappedTuple = mappedInput.map(x => (x._1,(x._2,1)))
  val mappedTuple = mappedInput.mapValues(x => (x,1))
  //input (25,(100,1)) (30,(200,1)) (25,(100,1)) (30,(100,1)) -> output (25,(200,2))(30,(300,2))
  val mappedFinal = mappedTuple.reduceByKey((x,y) => ((x._1 + y._1),(x._2 + y._2)))
  //input (25,(200,2))(30,(300,2)) -> output (25,100) (30,150)
  //val result = mappedFinal.map(x => (x._1, x._2._1/x._2._2))
  val result = mappedFinal.mapValues(x => (x._1/x._2)).sortBy(x=>x._2,false)
  
  println("Output:")
  val resultFinal = result.collect
  //resultFinal.foreach(println)
  for(i <- resultFinal) {
    println(i._1 + ":" + i._2)
  }
  //scala.io.StdIn.readLine()   //this statement is to visualize the DAG
  
}