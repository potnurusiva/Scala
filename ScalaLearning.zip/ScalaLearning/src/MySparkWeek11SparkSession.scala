import org.apache.spark.sql.SparkSession
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import java.sql.Timestamp
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.types.StructField



object MySparkWeek11SparkSession extends App{
  
  
  println("Entering into Spark")
  Logger.getLogger("org").setLevel(Level.ERROR)
  
  //one way
  /*
  val spark = SparkSession.builder()
              .appName("MySparkWeek11SparkSession")
              .master("local[2]")
              .getOrCreate()
  
  spark.stop()
  * 
  */
  //2nd way
  val sparkConf =new SparkConf()
  sparkConf.set("spark.app.name","MySparkWeek11SparkSession")
  sparkConf.set("spark.master","local[2]")
  
  val spark = SparkSession.builder()
              .config(sparkConf)
              .getOrCreate()
  
  //val ordersDf = spark.read.csv("C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/orders.csv")            
  //val ordersDf: Dataset[Row] = spark.read
  val ordersDf  = spark.read
                 .option("header",true)
                 .option("inferSchema",true)
                 .csv("C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/orders.csv") 
  println("Spark Dataframe - orders")
  ordersDf.show(50)
  println("Spark Dataframe - Schema")     
  //ordersDf.filter("order_ids < 10").show //DF-column order_ids doesn't exists but it will not show error at compile time
  
  ordersDf.printSchema()
  //ordersDf.rdd.collect().foreach(println) //converting df to RDD
  println("Query data")
  val groupedOrdersDf = ordersDf.repartition(4)
                        .select("order_id","order_customer_id")
                        .where("order_customer_id > 10000")
                        .groupBy("order_customer_id")
                        .count()
  
  groupedOrdersDf.show()
  //groupedOrdersDf.foreach(x => {println(x)})
  
  Logger.getLogger(getClass.getName).info("My application completed successfully")
  
  println("Conversion of a DataFrame to a DataSet")
  case class ordersData(order_id: Int, order_date: Timestamp,order_customer_id: Int, order_status: String)
  
  import spark.implicits._   //this is required to convert DF to DS but inside Spark session not at the top
  val ordersDs = ordersDf.as[ordersData]
  
  ordersDs.filter(x => x.order_id < 10)
  
  //Standard way of reading the data and loading it to DS/DF
  val ordersDf1 = spark.read
                 .format("csv")
                 .option("header", true)
                 .option("inferSchema", true)
                 .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/orders.csv")
                 .load
  ordersDf1.show
  ordersDf1.printSchema
  
  println("Players Json data")
  val playersDf = spark.read
                 .format("json")
                 .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/players.json")
                 .load
  playersDf.show
  playersDf.printSchema
  
  println("Players Json corrupted data")
  val players1Df = spark.read
                 .format("json")
                 .option("header", true)
                 .option("inferSchema", true)
                // .option("mode","PERMISSIVE") //Default mode
                 .option("mode","DROPMALFORMED")
                // .option("mode","FAILFAST")
                 .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/players1.json")
                 .load
  players1Df.show(false)
  players1Df.printSchema
  
  
  println("Parquet file format") //Default file format in Spark
  val usersDf = spark.read
                .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/users.parquet")
                .load
  usersDf.show()
  usersDf.printSchema()
  
  
  
  //Explicit Schema 
  //1.programmatic approach - spark data types
  println("Explicit Schema through programmatic approach")
  val orderSchema = StructType(List(
      StructField("orderId",IntegerType,true),
      StructField("orderDate",TimestampType,true),
      StructField("customerId",IntegerType,true),
      StructField("status",StringType,true)
      )
      )
      
  val ordersDf2 = spark.read
                 .format("csv")
                 .option("header", true)
                 .option("inferSchema", true)
                 .schema(orderSchema)
                 .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/orders.csv")
                 .load
                 
  ordersDf2.show
  ordersDf2.printSchema
  //2. String DDL approach - scala data types              
  println("Explicit Schema through StringDDL approach")
  val ordersSchemaDDL = "orderId Int, orderDate TimeStamp, custId Int, orderStatus String"
  val ordersDf3 = spark.read
                 .format("csv")
                 .option("header", true)
                 .option("inferSchema", true)
                 .schema(ordersSchemaDDL)
                 .option("path","C:/Users/posiva/Desktop/Work/Exxon/BigData/11Week_ApacheSparkStructuredAPIPart1/orders.csv")
                 .load
                 
  ordersDf3.show
  ordersDf3.printSchema
  
  
  spark.stop()
              
              
              
  
  
}




